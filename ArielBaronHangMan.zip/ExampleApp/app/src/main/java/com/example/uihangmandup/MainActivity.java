package com.example.uihangmandup;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    // Button btnA,btnB,btnC,btnD,btnE,btnF,btnG,btnH,btnI,btnJ,btnK,btnL,btnM,btnN,btnO,btnP,btnQ,btnR,btnS,btnT,btnU,btnV,btnW,btnX,btnY,btnZ;
    Button  btnRestart, btnSave, btnLoad, btnExit;
    Button btnRed, btnGreen, btnHide, btnShow;

    Button btnRevert;
    Button btnHint;
    Button [] abc = new Button[26];  // Keyboard buttons
    TextView txtHiddenWord; // The hidden word to be guessed
    TextView txtScore; // The score message
    ImageView imgHangman; // The hangman image
    Drawable[] hungMan = new Drawable[7]; // Images of the hung man
    GameManager gm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        btnRed = findViewById(R.id.btnRed);
        btnGreen = findViewById(R.id.btnGreen);
        btnHide = findViewById(R.id.btnHide);
        btnShow = findViewById(R.id.btnShow);

        btnHint = findViewById(R.id.btnSolve);
        btnRevert = findViewById(R.id.btnRevert);
        // Initialize the buttons
        for (int i = 0; i < abc.length; i++) {
            char c =(char)('A'+i);
            String str="btn"+c;
            int resID= getResources().getIdentifier(str,"id",getPackageName());
            abc[i]=findViewById(resID);
        }
        btnRestart=findViewById(R.id.btnRes);

        // Connect the buttons
        View.OnClickListener listener = this::letterClick;
        for (Button btn : abc) {
            btn.setOnClickListener(listener);
        }
        btnRestart.setOnClickListener(view -> restart() );
//        btnExit.setOnClickListener(view -> { finishAffinity(); } );
//        btnHint.setOnClickListener(view -> getHint() );

        // Initialize the hidden word and the score text views
        txtHiddenWord = findViewById(R.id.tex);

        // Initialize the hung man images
        for (int i = 0; i < hungMan.length; i++)
        {
            String drawableName = "hm" + i;
            int resID = getResources().getIdentifier(drawableName , "drawable", getPackageName());
            hungMan[i] = getResources().getDrawable(resID, null);
        }
        imgHangman = findViewById(R.id.hangman_image);
        imgHangman.setImageDrawable(hungMan[0]);

        UnitTests.runAllTests(); // in Logcat serch: HangmanUnitTests

        // Start the game
        gm = new GameManager(this);
        restart();
    }

    /**
     * Updates keyboard status according to the guessed letters. if 1 / -1 the button is disabled, if 0 the button is enabled.
     * The button color is changed according to the status: 0 will be grey,  1 will be green and -1 will be red.
     * @param guessed - Array of guessed letters. Every cell in the array indicates if the letter was not guessed yet (0), guessed and correct (1), guessed and incorrect (-1)
     */
    public void updateLetters(int[] guessed, String what)
    {
        for (int i = 0; i < guessed.length && i < abc.length; i++)
        {
            switch (guessed[i])
            {
                case 0:  // never guessed
                    abc[i].setEnabled(true);
                    abc[i].setBackgroundColor(Color.BLUE);
                    abc[i].setBackgroundTintList(ColorStateList.valueOf(Color.BLUE));
                    break;
                case 1:  // guessed and correct
                    abc[i].setEnabled(false);
                    abc[i].setBackgroundColor(what.equals("all")?Color.GREEN:Color.RED);
                    abc[i].setBackgroundTintList(what.equals("all")?ColorStateList.valueOf(Color.GREEN):ColorStateList.valueOf(Color.RED));
                    break;
                case -1:  // guessed and not-correct
                    if (what.equals("all"))
                    {
                        abc[i].setEnabled(false);
                        abc[i].setBackgroundColor(Color.RED);
                        abc[i].setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                    }
                    break;
                default:
                    break;
            }
        }
    }

    public void updateDisplayWord(String dispWord)
    {
        String str = "";
        for (int i=0; i<dispWord.length()-1; i++)
        {
            str += dispWord.charAt(i) +" " ;
        }
        str += dispWord.charAt(dispWord.length()-1);
        txtHiddenWord.setText(str);
    }

    public void updateScore()
    {
        txtScore.setText("Your score: " + gm.getScore());
        txtScore.setVisibility(View.VISIBLE);
    }

    public void drawHungMan(int misses)
    {
        if (misses >= 1 && misses <= hungMan.length)
        {
            imgHangman.setImageDrawable(hungMan[misses]);
        }
        else
        {
            imgHangman.setImageDrawable(hungMan[0]);
        }
    }

    public void announceGameOver(char status)
    {
        if (status == 'V')
            Toast.makeText(getApplicationContext(),"You won :)",Toast.LENGTH_LONG).show();
        else if (status == 'L')
            Toast.makeText(getApplicationContext(),"You lost!",Toast.LENGTH_LONG).show();
    }

    public void guess()
    {
        Toast.makeText(getApplicationContext(),"Guessing the word is not yet implemented",Toast.LENGTH_SHORT).show();
    }

    public void Solve()
    {
        gm.Solve();

    }
    public void restart()
    {
        gm.restart();
    }

    public void enableKeyboard()
    {
        for (Button btn : abc)
        {
            btn.setBackgroundColor(Color.BLUE);
            btn.setBackgroundTintList(ColorStateList.valueOf(Color.BLUE));
            btn.setEnabled(true);
        }
    }

    public void disableKeyboard()
    {
        for (Button btn : abc)
        {
            btn.setEnabled(false);
        }
    }

    public void letterClick(View v)
    {
        Button btn = (Button) v;
        String letter = btn.getText().toString();
        char c = letter.charAt(0);

        // 1. Let GameManager handle the guess
        gm.checkLetter(c);

        // 3. Update the guessed letter colors
        updateLetters(gm.guessed, "all"); // immediately reflect correct/incorrect

        // 4. Disable this button
        disableLetter(c);

        // 6. Check game over
        char gameStatus = gm.getGameStatus();
        if (gameStatus != 'P') disableKeyboard();

        if (gameStatus == 'V')
            Toast.makeText(getApplicationContext(),"You won!",Toast.LENGTH_SHORT).show();
        else if (gameStatus == 'L')
            Toast.makeText(getApplicationContext(),"You lost!",Toast.LENGTH_SHORT).show();
    }


    public void disableLetter(char c)
    {
        Button btn = abc[c-'A'];
        btn.setEnabled(false);
    }
    public void controlBtnClick(View v){
        for (Button button : abc) {
            if (v.getId() == btnRed.getId()) {

                button.setBackgroundColor(Color.RED);
                button.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
            }
            if (v.getId() == btnGreen.getId()) {
                button.setBackgroundColor(Color.GREEN);
                button.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
            }
            if (v.getId() == btnHide.getId()) {
                button.setVisibility(View.INVISIBLE); // hidden but keeps space
            }
            if (v.getId() == btnShow.getId()) {
                button.setVisibility(View.VISIBLE); // hidden but keeps space
            }
            if (v.getId() == btnRevert.getId()) {
                button.setBackgroundColor(Color.BLUE);
                button.setBackgroundTintList(ColorStateList.valueOf(Color.BLUE));
            }
            if (v.getId() == btnHint.getId()){
                Solve();
            }


        }
    }
}
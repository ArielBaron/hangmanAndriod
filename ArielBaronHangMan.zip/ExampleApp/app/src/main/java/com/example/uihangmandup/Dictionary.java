package com.example.uihangmandup;

import java.util.ArrayList;
import java.util.ListIterator;

public class Dictionary
{
    String[] dictionary;  // Simple Word list
    int current;  // Index of current word in simple dictionary
    boolean simple;
    ArrayList<String> wordsList;
    ListIterator<String> currentWord;

    public Dictionary()
    {
        this(false);
    }
    public Dictionary(boolean simple)
    {
        this.dictionary = new String[] {"HELLO", "APPLE", "BANANA", "CHERRY", "DATE", "FIG", "GRAPE", "THESAURUS", "ELEPHANT", "UNIVERSITY"};
        this.current = 0;

        this.simple = simple;
        if (!simple)
        {
            this.wordsList = new ArrayList<String>();
            reshuffle();
            currentWord = wordsList.listIterator();
        }
    }

    private void loadWords()
    {
        wordsList.add("HELLO");
        wordsList.add("APPLE");
        wordsList.add("BANANA");
        wordsList.add("CHERRY");
        wordsList.add("DATE");
        wordsList.add("FIG");
        wordsList.add("GRAPE");
        wordsList.add("THESAURUS");
        wordsList.add("ELEPHANT");
        wordsList.add("UNIVERSITY");
    }

    public String getRandomWord()
    {
        if (simple)
        {
            current = (int)(Math.random() * dictionary.length);
            return dictionary[current];
        }

        if (!currentWord.hasNext())
        {
            reshuffle();
            currentWord = wordsList.listIterator();
        }
        return currentWord.next();
    }

    private void reshuffle()
    {
        String s;
        int count = 0, current;

        this.wordsList.clear();
        while (count < dictionary.length) {
            current = (int)(Math.random() * dictionary.length);
            s = dictionary[current];
            if (!wordsList.contains(s)) {
                wordsList.add(s);
                count++;
            }
        }
    }
}

package com.example.uihangmandup;

import android.util.Log;

/**
 * Unit test class for Word and Dictionary
 * Call these methods from MainActivity's onCreate
 */
public class UnitTests {

    private static final String TAG = "HangmanUnitTests";

    /**
     * Test the Word class
     * This test checks all Word operations according to slide 11 guidelines
     */
    public static void testWord() {
        Log.d(TAG, "==================== Starting Word Test ====================");

        // 1. Create new Word object for the word BANANA
        Word word = new Word("BANANA");
        Log.d(TAG, "1. Created Word for the word BANANA");

        // 2. Print getDisplayWord
        String display = word.getDisplayWord();
        Log.d(TAG, "2. getDisplayWord: " + display);
        Log.d(TAG, "   Expected: ______ (6 underscores)");

        // 3. Check letter B (appears once)
        boolean foundB = word.checkLetter('B');
        Log.d(TAG, "3. checkLetter('B') returned: " + foundB);

        // 4. Print returned value and displayWord
        display = word.getDisplayWord();
        Log.d(TAG, "4. After checking B:");
        Log.d(TAG, "   Return value: " + foundB + " (expected: true)");
        Log.d(TAG, "   displayWord: " + display + " (expected: B_____)");

        // 5. Check letter A (appears 3 times)
        boolean foundA = word.checkLetter('A');
        Log.d(TAG, "5. checkLetter('A') returned: " + foundA);

        // 6. Print returned value and displayWord
        display = word.getDisplayWord();
        Log.d(TAG, "6. After checking A:");
        Log.d(TAG, "   Return value: " + foundA + " (expected: true)");
        Log.d(TAG, "   displayWord: " + display + " (expected: _A_A_A)");

        // 7. Check letter X (doesn't appear)
        boolean foundX = word.checkLetter('X');
        Log.d(TAG, "7. checkLetter('X') returned: " + foundX);

        // 8. Print returned value and displayWord
        display = word.getDisplayWord();
        Log.d(TAG, "8. After checking X:");
        Log.d(TAG, "   Return value: " + foundX + " (expected: false)");
        Log.d(TAG, "   displayWord: " + display + " (expected: _A_A_A - no change)");

        // 9. Check victory (negative answer)
        boolean victory = word.checkDisplayWord();
        Log.d(TAG, "9. checkDisplayWord() returned: " + victory);
        Log.d(TAG, "   Expected: false (still has underscores)");

        // 10. Check letter N (appears 2 times)
        boolean foundN = word.checkLetter('N');
        Log.d(TAG, "10. checkLetter('N') returned: " + foundN);

        // 11. Print returned value and displayWord
        display = word.getDisplayWord();
        Log.d(TAG, "11. After checking N:");
        Log.d(TAG, "    Return value: " + foundN + " (expected: true)");
        Log.d(TAG, "    displayWord: " + display + " (expected: _ANANA)");

        // 12. Check victory (positive answer after completing the word)
        word.checkLetter('B'); // Already checked, but ensures B is there
        victory = word.checkDisplayWord();
        display = word.getDisplayWord();
        Log.d(TAG, "12. After completing word:");
        Log.d(TAG, "    displayWord: " + display + " (expected: BANANA)");
        Log.d(TAG, "    checkDisplayWord() returned: " + victory + " (expected: true)");

        Log.d(TAG, "==================== End of Word Test ====================\n");
    }

    /**
     * Test the Dictionary class
     * This test checks Dictionary operations according to slide 16 guidelines
     */
    public static void testDictionary() {
        Log.d(TAG, "==================== Starting Dictionary Test ====================");

        // Create new Dictionary object
        Dictionary dict = new Dictionary();
        Log.d(TAG, "Created Dictionary object");

        // Set number of words in dictionary (10 words by definition)
        int numWords = 10;
        int iterations = numWords + 2; // Run numWords + 2 times

        Log.d(TAG, "Number of words in dictionary: " + numWords);
        Log.d(TAG, "Running getRandomWord() " + iterations + " times:\n");

        // Run loop for numWords + 2 iterations
        for (int i = 1; i <= iterations; i++) {
            String word = dict.getRandomWord();
            Log.d(TAG, i + ". getRandomWord() returned: " + word);

            // Special marker after last word in dictionary
            if (i == numWords) {
                Log.d(TAG, "   --- Completed first round of all words in dictionary ---");
            }
        }

        Log.d(TAG, "\nExpected results:");
        Log.d(TAG, "1. All first 10 words should be different (random order)");
        Log.d(TAG, "2. Words 11-12 should be from dictionary but in new random order");
        Log.d(TAG, "3. No repeated words in first 10");

        // Additional test - verify all dictionary words appear
        Log.d(TAG, "\n--- Testing complete dictionary coverage ---");
        Dictionary dict2 = new Dictionary();
        java.util.HashSet<String> wordsFound = new java.util.HashSet<>();

        for (int i = 0; i < numWords; i++) {
            String word = dict2.getRandomWord();
            wordsFound.add(word);
        }

        Log.d(TAG, "Number of unique words received: " + wordsFound.size());
        Log.d(TAG, "Words received: " + wordsFound);
        Log.d(TAG, "Expected: 10 unique words from dictionary");

        if (wordsFound.size() == numWords) {
            Log.d(TAG, "✓ Test passed successfully - all words appeared!");
        } else {
            Log.d(TAG, "✗ Error - not all words appeared");
        }

        Log.d(TAG, "==================== End of Dictionary Test ====================\n");
    }

    /**
     * Run all tests
     * Call this method from MainActivity's onCreate
     */
    public static void runAllTests() {
        Log.d(TAG, "\n\n");
        Log.d(TAG, "####################################################");
        Log.d(TAG, "###     Starting Unit Tests - Hangman Project   ###");
        Log.d(TAG, "####################################################");
        Log.d(TAG, "\n");

        testWord();
        testDictionary();

        Log.d(TAG, "\n");
        Log.d(TAG, "####################################################");
        Log.d(TAG, "###      All Tests Complete - Hangman Project    ###");
        Log.d(TAG, "####################################################");
        Log.d(TAG, "\n\n");
    }
}
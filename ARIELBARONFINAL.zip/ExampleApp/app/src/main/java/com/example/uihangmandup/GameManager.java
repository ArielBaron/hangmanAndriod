package com.example.uihangmandup;

import android.widget.Toast;

public class GameManager
{
    private Dictionary dictionary;  // Word list
    private MainActivity _hmUI; // a reference to the Hangman activity
    private Word current;  // The current word
    private int misses; // count of misses
    private String displayWord;  // The word as displayed to the user (including _ for unguessed letters)
    private char status; // ‘P’ – game in progress, ‘V’ – victory, ‘L’ – loss
    int[] guessed = new int[26]; //Used In MainActvity  Length  = 26 (guessed[0] is for ‘A’). every cell in the array indicates if the letter was not guessed yet (0), guessed and correct (1), guessed and incorrect (-1)
    int score, gameCount; // accumulated score of games

    public GameManager(MainActivity hmUI)
    {
        this._hmUI = hmUI;
        this.dictionary = new Dictionary();
        this.score = 0;
        this.gameCount = 0;
    }

    public void checkLetter(char letter)
    {
        if (current.checkLetter(letter))
        {
            guessed[letter-'A'] = 1;
            _hmUI.disableLetter(letter);
            _hmUI.updateDisplayWord(current.getDisplayWord());
        }
        else
        {
            guessed[letter-'A'] = -1;
            misses++;
            _hmUI.drawHungMan(misses);
        }
        if (isGameOver())
        {
            _hmUI.disableKeyboard();
            _hmUI.updateScore();
            _hmUI.announceGameOver(status);

        }
    }

    private boolean isGameOver()
    {
        if (misses >= 6)
        {
            status = 'L';
            return true;
        }
        if (check4Victory())
        {
            status = 'V';
            score += 1;
            return true;
        }
        return false;
    }

    // Returns true if the user has guessed all the letters in the word
    private boolean check4Victory()
    {
        return current.checkDisplayWord();
    }

    public void restart() {
        _hmUI.disableKeyboard();

        misses = 0;
        for (int i = 0; i < guessed.length; i++)
            guessed[i] = 0;
        // _hmUI.updateLetters(guessed);

        current = new Word(dictionary.getRandomWord());
        _hmUI.updateDisplayWord(current.getDisplayWord());
        _hmUI.drawHungMan(0);

        this.gameCount++;
        this.status = 'P';
        _hmUI.enableKeyboard();
    }

    public char getGameStatus()
    {
        return this.status;
    }

    public String getScore()
    {
        return score + " wins out of " + gameCount + " games";
    }
    // for now: still increases game count
    public void Solve() {
        // Reveal the full word directly
        _hmUI.updateDisplayWord(current.getWord());
        // Disable further input
        _hmUI.disableKeyboard();
        _hmUI.updateScore();

    }



}

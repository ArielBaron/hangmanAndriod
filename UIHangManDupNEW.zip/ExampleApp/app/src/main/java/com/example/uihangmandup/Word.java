package com.example.uihangmandup;

public class Word
{
    private String _word;
    private char[] displayWord;
    public Word(String word)
    {
        this._word = word.trim().toUpperCase();

        this.displayWord = new char[word.length()];
        for (int i = 0; i < word.length(); i++) {
            this.displayWord[i] = '_';
        }
    }

    public String getDisplayWord()
    {
        String retWord = "";
        for (int i = 0; i < this._word.length(); i++)
        {
            retWord += this.displayWord[i];
        }
        return retWord;
    }

    public boolean checkDisplayWord()
    {
        for (int i = 0; i < this._word.length(); i++)
        {
            if (this.displayWord[i] == '_')
                return false;
        }
        return true;
    }

    public boolean checkLetter(char letter)
    {
        boolean found = false;
        for (int i = 0; i < this._word.length(); i++)
        {
            if (this._word.charAt(i) == letter)
            {
                this.displayWord[i] = letter;
                found = true;
            }
        }
        return found;
    }
    public String getWord(){
        return _word;
    }
}
